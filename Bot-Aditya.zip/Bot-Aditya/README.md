i'm stardustlrlr

###### Clone this project

> cd /sdcard
> cp -r mlspacetoonV2 /$HOME
> cd
> cd mlspacetoonV2
> bash install.sh

###### Usage

> node index.js

## thanks for
mhank
affis
fadhil
mlspacetoon

URGENT? CHAT WhatsApp : 087714745440